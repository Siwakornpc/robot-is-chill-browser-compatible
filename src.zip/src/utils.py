from __future__ import annotations

import cv2
from discord.ext import menus
from discord.ext.menus.views import ViewMenuPages


from typing import Callable, List, Optional, Tuple, TypeVar, TYPE_CHECKING
from PIL import Image
import numpy as np

from .types import Color

from . import constants, errors

def recolor(sprite: Image.Image | np.ndarray, rgba: tuple[int, int, int, int] | Color) -> Image.Image:
    """Apply rgba color multiplication (0-255)"""
    if isinstance(rgba, Color):
        rgba = rgba.r, rgba.g, rgba.b, rgba.a
    arr = np.multiply(sprite, np.array(rgba) / 255, casting="unsafe").astype(np.uint8)
    if isinstance(sprite, np.ndarray):
        return arr
    return Image.fromarray(arr)

def composite(a, b, t):
    return (1.0 - t) * a + t * b

class Tile:
    """Represents a tile object, ready to be rendered."""

    def __init__(
            self,
            *,
            name: Optional[str] = None,
            variant: Optional[int] = None,
            color: Optional[Tuple[int, int]] = None,
            source: str = "vanilla",
            meta_level: int = 0,
            style: Optional[str] = None,
            custom: bool = False,
            images: Optional[List[Image.Image]] = None
    ):
        self.name = name
        self.variant = variant
        self.color = color
        self.source = source
        self.style = style
        self.meta_level = meta_level
        self.custom = custom
        self.images = images or []

    def __repr__(self) -> str:
        return f"<Tile {self.name} : {self.variant} with {self.color} from {'[generated]' if self.custom else self.source}>"


T = TypeVar("T")


def cached_open(path, *, cache: dict[str, T],
                fn: Callable[[str], T] = open) -> T:
    """Checks whether a path is in the cache, and if so, returns that element.

    Otherwise calls the function on the path.
    """
    if path in cache:
        return cache[path]
    cache[path] = result = fn(path)
    return result

class ButtonPages(ViewMenuPages,inherit_buttons=False):
    @menus.button('⏮', position=menus.First())
    async def go_to_first_page(self, payload):
        await self.show_page(0)

    @menus.button('◀', position=menus.First(1))
    async def go_to_previous_page(self, payload):
        await self.show_checked_page(self.current_page - 1)

    @menus.button('▶', position=menus.Last(1))
    async def go_to_next_page(self, payload):
        await self.show_checked_page(self.current_page + 1)

    @menus.button('⏭', position=menus.Last(2))
    async def go_to_last_page(self, payload):
        max_pages = self._source.get_max_pages()
        last_page = max(max_pages - 1, 0)
        await self.show_page(last_page)

    @menus.button('⏹', position=menus.Last())
    async def stop_pages(self, payload):
        self.stop()


def split_escaped(string: str, splitters: list[str], keep: bool = False, with_prefix: bool = False) -> list[str]:
    res = []
    buf = ""
    last_escaped = False
    last_splitter = None
    for c in string:
        if last_escaped:
            buf += c
            last_escaped = False
            continue
        if c == "\\":
            last_escaped = True
            if keep:
                buf += c
            continue
        if c in splitters:
            res.append((buf, last_splitter) if with_prefix else buf)
            last_splitter = c
            buf = ""
            continue
        buf += c
    res.append((buf, last_splitter) if with_prefix else buf)
    return res


def find_unescaped(string: str, target: tuple[str]) -> int:
    last_escaped = False
    for i, c in enumerate(string):
        if last_escaped:
            last_escaped = False
            continue
        if c == "\\":
            last_escaped = True
            continue
        if c in target:
            return i
    return -1


def sanitize(string: str):
    return string.replace('`', '').replace('\n', '')[:32]


def check_size(*dst_size):
    if dst_size[0] > constants.MAX_TILE_SIZE or dst_size[1] > constants.MAX_TILE_SIZE:
        raise errors.TooLargeTile(dst_size)
