from __future__ import annotations

import string
from dataclasses import dataclass
from io import BytesIO
from sqlite3.dbapi2 import Row
from typing import AsyncGenerator, Iterable, Any

import re
import asqlite
import numpy as np
import requests
import tldextract as tldextract
from PIL import Image

from src.log import LOG
from .types import TilingMode

from . import constants
from .constants import DIRECTIONS


class Database:
    """Everything relating to persistent readable & writable data."""
    conn: asqlite.Connection
    bot: None
    filter_cache: dict[str, (Image.Image, bool)]
    palette_store: dict[(str, str), Image.Image]

    def __init__(self, bot):
        self.filter_cache = {}
        self.palette_store = {}
        self.bot = bot

    async def connect(self, db: str) -> None:
        """Startup."""
        # not checking for same thread probably is a terrible idea but
        # whateverrr
        self.conn = await asqlite.connect(db, check_same_thread=False)
        async with self.conn.cursor() as cur:
            await cur.execute("VACUUM;")

        def regexp(x, y):
            return bool(re.search(x, y))

        self.conn.get_connection().create_function('regexp', 2, regexp)
        LOG.info("Initialized database connection.")
        await self.create_tables()
        LOG.debug("Verified database tables.")
        await self.store_palettes()
        LOG.debug("Stored palettes.")

    async def store_palettes(self):
        async with self.conn.cursor() as cur:
            res = await cur.execute("""
                SELECT name, source, data FROM palettes
            """)
            res = [(*row, ) for row in await res.fetchall()]
        vanilla_palettes = []
        for (name, source, data) in res:
            im = Image.open(BytesIO(data))
            im.load()
            self.palette_store[(name, None)] = im.copy()
            self.palette_store[(name, source)] = im.copy()
            if source == "vanilla":
                vanilla_palettes.append((name, im.copy()))
        # Hack to prioritize vanilla
        for name, pal in vanilla_palettes:
            self.palette_store[(name, None)] = pal

    async def close(self) -> None:
        """Teardown."""
        if hasattr(self, "conn"):
            await self.conn.close()

    async def create_tables(self) -> None:
        """Creates tables in the database according to a schema in code.

        (Useful for documentation.)
        """
        async with self.conn.cursor() as cur:
            await cur.executescript(
                '''
                CREATE TABLE IF NOT EXISTS tiles (
                    name TEXT NOT NULL,
                    sprite TEXT NOT NULL,
                    source TEXT NOT NULL,
                    version INTEGER NOT NULL,
                    active_color_x INTEGER NOT NULL DEFAULT 0,
                    active_color_y INTEGER NOT NULL DEFAULT 3,
                    inactive_color_x INTEGER,
                    inactive_color_y INTEGER,
                    tiling TEXT NOT NULL DEFAULT "none",
                    -- It would be better to store these in a separate table but idrc
                    tags TEXT NOT NULL DEFAULT "",
                    extra_frames TEXT,
                    object_id TEXT,
                    displacement_x INTEGER NOT NULL DEFAULT 0,
                    displacement_y INTEGER NOT NULL DEFAULT 0,
                    UNIQUE(name, version)
                );
                CREATE TABLE IF NOT EXISTS levels (
                    id TEXT NOT NULL,
                    world TEXT NOT NULL,
                    name TEXT NOT NULL,
                    subtitle TEXT,
                    number INTEGER,
                    style INTEGER,
                    parent TEXT,
                    map_id TEXT,
                    UNIQUE(id, world)
                );
                CREATE TABLE IF NOT EXISTS custom_levels (
                    code TEXT UNIQUE NOT NULL,
                    name TEXT NOT NULL,
                    subtitle TEXT,
                    author TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS letters (
                    char TEXT NOT NULL,
                    width INTEGER NOT NULL,
                    mode TEXT NOT NULL,
                    frames BLOB NOT NULL
                );
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER UNIQUE PRIMARY KEY,
                    blacklisted BOOLEAN NOT NULL DEFAULT false
                );
                CREATE TABLE IF NOT EXISTS filters (
                    name STRING NOT NULL,
                    absolute BOOLEAN NOT NULL,
                    author INT NOT NULL,
                    upload_time INT,
                    data BLOB NOT NULL
                );
                CREATE TABLE IF NOT EXISTS macros (
                    name TEXT UNIQUE PRIMARY KEY,
                    value TEXT NOT NULL,
                    description TEXT NOT NULL,
                    creator INT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS palettes (
                    name TEXT NOT NULL,
                    source TEXT NOT NULL,
                    data BLOB NOT NULL,
                    hash INT UNIQUE NOT NULL
                );
                '''
            )

    async def tile(self, name: str, *, maximum_version: int = 1000) -> TileData | None:
        """Convenience method to fetch a single thing of tile data.

        Returns None on failure.
        """
        row = await self.conn.fetchone(
            '''
            SELECT * FROM tiles
            WHERE name == ? AND version <= ?
            ORDER BY version DESC;
            ''',
            name, maximum_version
        )
        if row is None:
            return None
        return TileData.from_row(row)

    def palette(self, name: str, source: str = None, strict: bool = False) -> Image.Image | None:
        """Convenience method to fetch a palette from the database.

        Returns None on failure.
        """
        if type(name) is tuple:
            name, source = name
        res = self.palette_store.get((name, source))
        if not strict and res is None and source is not None and source != "vanilla":
            res = self.palette_store.get((name, "vanilla"))
        if not strict and res is None and source is not None:
            res = self.palette_store.get((name, None))
        return res

    async def tiles(self, names: Iterable[str], *, maximum_version: int = 1000) -> AsyncGenerator[TileData, None]:
        """Convenience method to fetch a single thing of tile data.

        Returns None on failure.
        """
        async with self.conn.cursor() as cur:
            for name in names:
                await cur.execute(
                    '''
                    SELECT * FROM tiles
                    WHERE name == ? AND version < ?
                    ORDER BY version DESC;
                    ''',
                    name, maximum_version
                )
                row = await cur.fetchone()
                if row is not None:
                    yield TileData.from_row(row)

    def plate(self, direction: int | None,
              wobble: int) -> tuple[Image.Image, tuple[int, int]]:
        """Plate sprites.

        Raises FileNotFoundError on failure.
        """
        # Strongly assure type to protect against potential security issue
        assert type(
            direction) == int or direction is None, f"Plate of type {type(direction)} wasn't allowed? This shouldn't happen."
        if direction is None:
            return (
                Image.open(
                    f"data/plates/plate_property_0_{wobble + 1}.png").convert("RGBA"),
                (0, 0)
            )
        return (
            Image.open(
                f"data/plates/plate_property{DIRECTIONS.get(direction, '')}_0_{wobble + 1}.png").convert("RGBA"),
            (3, 3)
        )

    async def get_filter(self, name: str):
        """Get a filter from the database."""
        if name not in self.filter_cache:
            async with (self.conn.cursor() as cur):
                await cur.execute("SELECT absolute, author, upload_time, data FROM filters WHERE name == ?;", name)
                res = await cur.fetchone()
                if res is None: return None
                absolute, author, upload_time, data = res
                im = Image.open(BytesIO(data))
                im.load()          
                final = absolute, author, None if upload_time is None else upload_time / 1000, im
                self.filter_cache[name] = final
                return final
        return self.filter_cache[name]


@dataclass
class TileData:
    name: str
    sprite: str
    source: str
    inactive_color: tuple[int, int] | None
    active_color: tuple[int, int]
    tiling: TilingMode
    tags: list[str]
    extra_frames: list[int]
    displacement: tuple[int, int]

    @classmethod
    def from_row(cls, row: Row) -> TileData:
        """Create a tiledata object from a database row."""
        tags: str | None = row["tags"]
        if tags is not None:
            tags = tags.strip()
            if len(tags) == 0:
                tags = None
                
        extra_frames: str | None = row["extra_frames"]
        if extra_frames is not None:
            extra_frames = extra_frames.strip()
            if len(extra_frames) == 0:
                extra_frames = None

        return TileData(
            row["name"],
            row["sprite"],
            row["source"],
            (row["inactive_color_x"], row["inactive_color_y"]) if row["inactive_color_x"] is not None else None,
            (row["active_color_x"], row["active_color_y"]),
            TilingMode.parse(row["tiling"]),
            tags.split("\t") if tags is not None else [],
            [int(frame) for frame in (extra_frames).split("\t")] if extra_frames is not None else [],
            (row["displacement_x"], row["displacement_y"])
        )


@dataclass
class LevelData:
    id: str
    world: str
    name: str
    subtitle: str | None
    number: int | None
    style: int | None
    parent: str | None
    map_id: str | None

    @classmethod
    def from_row(cls, row: Row) -> LevelData:
        """Level from db row."""
        return LevelData(*row)

    def display(self) -> str:
        """The level display string."""
        if self.parent is None or self.parent == "<empty>":
            return self.name
        if self.map_id is not None and self.map_id != "<empty>":
            return f"{self.parent}-{self.map_id}: {self.name}"
        if self.style is not None and self.number is not None:
            if self.style == 0:
                # numbers
                return f"{self.parent}-{self.number}: {self.name}"
            if self.style == 1:
                # letters
                letter = string.ascii_lowercase[self.number]
                return f"{self.parent}-{letter}: {self.name}"
            if self.style == 2:
                # extra dots
                return f"{self.parent}-extra {self.number}: {self.name}"
        return self.name  # raise RuntimeError("Level is in a bad state")

    def unique(self) -> str:
        """Uniquely identifying string."""
        return f"{self.world}/{self.id}"


@dataclass
class CustomLevelData:
    code: str
    name: str
    subtitle: str | None
    author: str

    @classmethod
    def from_row(cls, row: Row) -> CustomLevelData:
        """Level from db row."""
        return CustomLevelData(*row)

    def unique(self) -> str:
        """Uniquely identifying string."""
        return self.code
